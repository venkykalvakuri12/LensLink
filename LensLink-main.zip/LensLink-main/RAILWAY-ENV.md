# Railway Environment Variables Configuration
# Copy these to Railway dashboard under Environment Variables

MONGODB_URI=mongodb+srv://saikumarreddyappidi274_db_user:Prabkal99@cluster0.qbmu8a8.mongodb.net/lenslink?retryWrites=true&w=majority
JWT_SECRET=your-super-secret-jwt-key-for-production-use
NODE_ENV=production
PORT=8080

# Instructions:
# 1. Go to Railway dashboard
# 2. Select your LensLink project  
# 3. Go to Variables tab
# 4. Add each variable above (name=value)
# 5. Redeploy the service